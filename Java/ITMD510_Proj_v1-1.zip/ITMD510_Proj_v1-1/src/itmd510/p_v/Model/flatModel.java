package itmd510.p_v.Model;

/*NAME:Vineet Sampat
CWID:A20402683
DATE: 12/02/2017
SOURCE CODE:flatModel.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

//This Class includes getter's and setter's which are used in our Database.

public class flatModel extends leaseModel {

	private String flatID;
	private String houseID;
	private String flatType;
	private String houseAddress;
	private String flatSize;
	private Boolean flatAvailability;

	public String getFlatID() {
		return flatID;
	}

	public void setFlatID(String flatID) {
		this.flatID = flatID;
	}

	public String getHouseID() {
		return houseID;
	}

	public void setHouseID(String houseID) {
		this.houseID = houseID;
	}

	public String getFlatType() {
		return flatType;
	}

	public void setFlatType(String flatType) {
		this.flatType = flatType;
	}

	public String getHouseAddress() {
		return houseAddress;
	}

	public void setHouseAddress(String houseAddress) {
		this.houseAddress = houseAddress;
	}

	public String getFlatSize() {
		return flatSize;
	}

	public void setFlatSize(String flatSize) {
		this.flatSize = flatSize;
	}

	public Boolean getFlatAvailability() {
		return flatAvailability;
	}

	public void setFlatAvailability(Boolean flatAvailability) {
		this.flatAvailability = flatAvailability;
	}

	public flatModel() {

	}

	public flatModel(String flatID, String houseID, String houseAddress, String flatType, String flatSize) {
		this.flatID = flatID;
		this.houseID = houseID;
		this.houseAddress = houseAddress;
		this.flatType = flatType;
		this.flatSize = flatSize;
	}

}
