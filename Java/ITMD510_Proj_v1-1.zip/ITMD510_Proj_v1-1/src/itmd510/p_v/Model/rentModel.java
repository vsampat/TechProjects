package itmd510.p_v.Model;

/*NAME:Vineet Sampat
CWID:A20402683
DATE: 12/02/2017
SOURCE CODE:rentModel.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

//This Class includes getter's and setter's which are used in our Database.

public class rentModel extends leaseModel {

	private int rentID;
	private double rentAmount;
	private double rentBillAmount;
	private double penaltyAmount;
	private String payDate;
	private String dueDate;
	private int leaseID;

	public int getRentID() {
		return rentID;
	}

	public void setRentID(int rentID) {
		this.rentID = rentID;
	}

	public double getRentAmount() {
		return rentAmount;
	}

	public void setRentAmount(double rentAmount) {
		this.rentAmount = rentAmount;
	}

	public double getRentBillAmount() {
		return rentBillAmount;
	}

	public void setRentBillAmount(double rentBillAmount) {
		this.rentBillAmount = rentBillAmount;
	}

	public double getPenaltyAmount() {
		return penaltyAmount;
	}

	public void setPenaltyAmount(double penaltyAmount) {
		this.penaltyAmount = penaltyAmount;
	}

	public String getPayDate() {
		return payDate;
	}

	public void setPayDate(String payDate) {
		this.payDate = payDate;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public int getLeaseID() {
		return leaseID;
	}

	public void setLeaseID(int leaseID) {
		this.leaseID = leaseID;
	}

	public rentModel() {
	}

	public rentModel(int RentID, double rentAmount, double rentBillAmount, int leaseID, String payDate, String dueDate,
			double penaltyAmount) {

		this.rentID = RentID;
		this.payDate = payDate;
		this.dueDate = dueDate;
		this.rentBillAmount = rentBillAmount;
		this.rentAmount = rentAmount;
		this.leaseID = leaseID;
		this.penaltyAmount = penaltyAmount;
	}

}
