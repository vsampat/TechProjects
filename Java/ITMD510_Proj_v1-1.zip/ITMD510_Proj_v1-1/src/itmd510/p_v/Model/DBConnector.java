package itmd510.p_v.Model;

/*NAME:Vineet Sampat
CWID: A20402683
DATE: 12/02/2017
SOURCE CODE:DBConnector.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

import java.sql.*;

//This Class is used for connecting to the Papademas Server so as to carryout CRUD Operations in the Database through GUI.

public class DBConnector {

	Connection con_prb = null; // variable to hold the established connection.

	public Connection getConnection() {
		System.out.println("Connecting to the MySQL Workbench database\n");
		// Connection to the database

		String url = "jdbc:mysql://www.papademas.net:3306/fp510?autoReconnect=true&useSSL=false"; // "jdbc:mysql://www.papademas.net:3306/fp510";
		String username = "fpuser";
		String password = "510";

		try {
			con_prb = DriverManager.getConnection(url, username, password); // connection
																			// string

			System.out.println("Connection string passed to server"); // connect
																		// to
																		// the
																		// DB

			if (con_prb != null) {
				System.out.println("Connected to the MySQL Workbench database\n");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		// checking the required drivers for jdbc connectivity
		try {
			Class.forName("com.mysql.jdbc.Driver");
		}

		catch (ClassNotFoundException e) {
			System.out.println("Required drivers for JDBC connectivity missing\n");
			e.printStackTrace();

		}

		return con_prb;

	}

	public void close() {
		// TODO Auto-generated method stub
		try {

			con_prb.close();

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

}
