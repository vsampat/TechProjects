package itmd510.p_v.Model;

/*NAME:Vineet Sampat
CWID:A20402683
DATE: 12/02/2017
SOURCE CODE:complaintsModel.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

//This Class includes getter's and setter's which are used in our Database.

public class complaintsModel extends leaseModel {

	private int complaintID;
	private String complaintDesc;
	private String startDate;
	private String lastUpdateDate;
	private String complaintStatus;
	private int leaseID;

	public int getComplaintID() {
		return complaintID;
	}

	public void setComplaintID(int complaintID) {
		this.complaintID = complaintID;
	}

	public String getComplaintDesc() {
		return complaintDesc;
	}

	public void setComplaintDesc(String complaintDesc) {
		this.complaintDesc = complaintDesc;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getComplaintStatus() {
		return complaintStatus;
	}

	public void setComplaintStatus(String complaintStatus) {
		this.complaintStatus = complaintStatus;
	}

	public int getLeaseID() {
		return leaseID;
	}

	public void setLeaseID(int leaseID) {
		this.leaseID = leaseID;
	}

	public complaintsModel() {

	}

	public complaintsModel(int complaintID, String complaintDesc, String startDate, String endDate,
			String complaintStatus, int leaseID) {
		this.complaintID = complaintID;
		this.complaintDesc = complaintDesc;
		this.startDate = startDate;
		this.lastUpdateDate = endDate;
		this.complaintStatus = complaintStatus;
		this.leaseID = leaseID;

	}

}
