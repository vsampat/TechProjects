package itmd510.p_v.Model;

/*NAME:Vineet Sampat
CWID:A20402683
DATE: 12/02/2017
SOURCE CODE:leaseModel.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

//This Class includes getter's and setter's which are used in our Database.

public class leaseModel extends registerModel {

	private int leaseID;
	private String leaseStartDate;
	private String leaseEndDate;
	private double bookingAmt;
	private double balBookingAmt;
	private String flatID;
	private int resID;

	public int getLeaseID() {
		return leaseID;
	}

	public void setLeaseID(int leaseID) {
		this.leaseID = leaseID;
	}

	public String getLeaseStartDate() {
		return leaseStartDate;
	}

	public void setLeaseStartDate(String leaseStartDate) {
		this.leaseStartDate = leaseStartDate;
	}

	public String getLeaseEndDate() {
		return leaseEndDate;
	}

	public void setLeaseEndDate(String leaseEndDate) {
		this.leaseEndDate = leaseEndDate;
	}

	public double getBookingAmt() {
		return bookingAmt;
	}

	public void setBookingAmt(double bookingAmt) {
		this.bookingAmt = bookingAmt;
	}

	public double getBalBookingAmt() {
		return balBookingAmt;
	}

	public void setBalBookingAmt(double balanceDepositAmount) {
		this.balBookingAmt = balanceDepositAmount;
	}

	public String getFlatID() {
		return flatID;
	}

	public void setFlatID(String flatID) {
		this.flatID = flatID;
	}

	public int getResID() {
		return resID;
	}

	public void setResID(int resID) {
		this.resID = resID;
	}

	public leaseModel() {
	}

	public leaseModel(int leaseID, String sDate, String eDate, double bookingAmt, double balDeposit, String flatID,
			int resID) {
		this.leaseID = leaseID;
		this.leaseStartDate = sDate;
		this.leaseEndDate = eDate;
		this.bookingAmt = bookingAmt;
		this.balBookingAmt = balDeposit;
		this.flatID = flatID;
		this.resID = resID;
	}
}
