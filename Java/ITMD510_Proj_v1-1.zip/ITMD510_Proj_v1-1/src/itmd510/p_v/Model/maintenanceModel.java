package itmd510.p_v.Model;

/*NAME:Vineet Sampat
CWID: A20402683
DATE: 12/02/2017
SOURCE CODE:maintenanceModel.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

//This Class includes getter's and setter's which are used in our Database.

public class maintenanceModel extends leaseModel {

	private int maintenanceID;
	private String maintenanceType;
	private String maintenanceDesc;
	private String status;
	private String startDate;
	private String lastUpdateDate;
	private int leaseID;

	
	
	public int getMaintenanceID() {
		return maintenanceID;
	}

	public void setMaintenanceID(int maintenanceID) {
		this.maintenanceID = maintenanceID;
	}

	public String getMaintenanceType() {
		return maintenanceType;
	}

	public void setMaintenanceType(String maintenanceType) {
		this.maintenanceType = maintenanceType;
	}

	public String getMaintenanceDesc() {
		return maintenanceDesc;
	}

	public void setMaintenanceDesc(String maintenanceDesc) {
		this.maintenanceDesc = maintenanceDesc;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public int getLeaseID() {
		return leaseID;
	}

	public void setLeaseID(int leaseID) {
		this.leaseID = leaseID;
	}

	public maintenanceModel(){
		
	}

	public maintenanceModel(int requestID, String maintenanceType , String maintenanceDesc, String maintStatus , String startDate, String lastUpdateDate, int leaseID)
	
	{
		this.maintenanceID = requestID;
		this.maintenanceType = maintenanceType;
		this.maintenanceDesc = maintenanceDesc;
		this.status = maintStatus;
		this.startDate = startDate;
		this.lastUpdateDate = lastUpdateDate;
		this.leaseID = leaseID;
	}
	
	
}
