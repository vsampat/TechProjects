package itmd510.p_v.Model;

/*NAME:Vineet Sampat
CWID:A20402683
DATE: 12/02/2017
SOURCE CODE:loginModel.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

//This Class includes getter's and setter's which are used in our Database.

public class loginModel {

	private String userID; // username

	private String password; // password

	public static String username;

	public loginModel() {
	}

	public loginModel(String userID, String password) {

		this.userID = userID; // This sets the Username when the Resident logins

		this.password = password; // This sets the Password when the Resident
									// logins.

	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
		username = userID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
