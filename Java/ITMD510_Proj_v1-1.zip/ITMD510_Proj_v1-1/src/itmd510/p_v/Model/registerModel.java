package itmd510.p_v.Model;

/*NAME:Vineet Sampat
CWID:A20402683
DATE: 12/02/2017
SOURCE CODE:registerModel.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

//This Class includes getter's and setter's which are used in our Database.

public class registerModel extends loginModel {

	private int resID;
	private String firstName;
	private String lastName;
	private String ContactNo;
	private String emailID;
	private String userID;
	private String password;
	private String confirmPswd;
	private String SSN;
	private String rtype;

	public int getResID() {
		return resID;
	}

	public void setResID(int resID) {
		this.resID = resID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContactNo() {
		return ContactNo;
	}

	public void setContactNo(String contactNo) {
		ContactNo = contactNo;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPswd() {
		return confirmPswd;
	}

	public void setConfirmPswd(String confirmPswd) {
		this.confirmPswd = confirmPswd;
	}

	public String getSSN() {
		return SSN;
	}

	public void setSSN(String sSN) {
		SSN = sSN;
	}

	public String getRtype() {
		return rtype;
	}

	public void setRtype(String rtype) {
		this.rtype = rtype;
	}

	public registerModel() {
	}

	//Parameterized constructor
	public registerModel(int resID, String firstname, String lastname, String ContactNo, String emailID, String userID,
			String password, String ConfrimPswd, String SSN, String rtype) {
		this.resID = resID;
		this.firstName = firstname;
		this.lastName = lastname;
		this.ContactNo = ContactNo;
		this.emailID = emailID;
		this.userID = userID;
		this.password = password;
		this.confirmPswd = ConfrimPswd;
		this.SSN = SSN;
		this.rtype = rtype;
	}

	//parameterized constructor to populate the table view
	public registerModel(int resID, String firstname, String lastname, String ContactNo, String emailID, String userID,
			String SSN, String rtype) {

		this.resID = resID;
		this.firstName = firstname;
		this.lastName = lastname;
		this.ContactNo = ContactNo;
		this.emailID = emailID;
		this.userID = userID;
		this.SSN = SSN;
		this.rtype = rtype;
	}

}
