package itmd510.p_v.DaoModel;

/*NAME:Vineet Sampat
CWID:A20402683
DATE: 12/02/2017
SOURCE CODE:registrationDaoModel.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import com.mysql.jdbc.PreparedStatement;

import itmd510.p_v.Model.DBConnector;
import itmd510.p_v.Model.registerModel;

public class registrationDaoModel {

	int getValue = 0;
	DBConnector connect = new DBConnector();
	private Statement statement = null;

	// This Creates Resident Table into the Database once the user registers for
	// our Housing through Registration Page.
	// ResID is used as the Primary key and Username is used as foreign key in
	// this table.

	public void createTable() throws SQLException {
		try {
			// create object and call class methods
			statement = connect.getConnection().createStatement();
			// pass sql statement
			String sql = "CREATE TABLE IF NOT EXISTS p_v_Resident" + "(ResID INT(7)," + "FirstName VARCHAR(50),"
					+ "LastName VARCHAR(50)," + "Contact VARCHAR(50)," + "Email VARCHAR(50)," + "Username VARCHAR(20),"
					+ "SSN VARCHAR(50)," + "Res_Type VARCHAR(10)," + "CONSTRAINT pk_resident PRIMARY KEY (ResID),"
					+ "CONSTRAINT fk_username FOREIGN KEY (Username) REFERENCES p_v_user(Username))";
			statement.executeUpdate(sql);
			System.out.println("Created resident table in given database...");
			// close connection

		} catch (SQLException e) {
			System.out.print(e.getMessage());
		}

		connect.close();

	}

	public registerModel insertUser(registerModel rm) throws ClassNotFoundException, SQLException {

		try {
			statement = connect.getConnection().createStatement();
			String Username = rm.getUserID();
			String Password = rm.getPassword();

			String query = "INSERT INTO p_v_user values('" + Username + "','" + Password + "');";
			System.out.println("Insertion into the table complete!!!");

			statement.executeUpdate(query);

			JOptionPane.showMessageDialog(null, "New user added " + "successfully!!!", "Success",
					JOptionPane.INFORMATION_MESSAGE);
		} catch (SQLException e) {
			rm = null;
			String errorMessage = e.getMessage();
			if (errorMessage.contains("Duplicate")) {
				JOptionPane.showMessageDialog(null, "Resident Name= " + errorMessage + " already " + "exists", "Error",
						JOptionPane.ERROR_MESSAGE);

			}

		}

		connect.close();

		return rm;

	}

	public registerModel insertResident(registerModel reg) throws ClassNotFoundException {

		try {

			// Set the parameters to the query
			String firstname = reg.getFirstName();
			String lastname = reg.getLastName();
			String contact = reg.getContactNo();
			String Email = reg.getEmailID();

			String username = reg.getUserID();
			String rtype = reg.getRtype();
			String ssn = reg.getSSN();

			statement = connect.getConnection().createStatement();

			String squery = null;

			squery = "Select count(resID) from p_v_Resident";

			String squery2 = "Select max(resID) from p_v_Resident";

			PreparedStatement maxres = (PreparedStatement) connect.getConnection().prepareStatement(squery2);

			System.out.println(squery);

			ResultSet rs = statement.executeQuery(squery);

			ResultSet rs1 = maxres.executeQuery(squery2);

			int gInt = 0;
			int max = 0;

			while (rs.next())
				gInt = rs.getInt(1) + 1;

			while (rs1.next())
				max = rs1.getInt(1);

			if (gInt == max) {

				gInt = gInt + 1;
			}

			PreparedStatement prb = (PreparedStatement) connect.getConnection()
					.prepareStatement("insert into p_v_Resident values(?,?,?,?,?,?,?,?)");

			prb.setInt(1, gInt);
			prb.setString(2, firstname);
			prb.setString(3, lastname);
			prb.setString(4, contact);
			prb.setString(5, Email);
			prb.setString(6, username);
			prb.setString(7, ssn);
			prb.setString(8, rtype);

			prb.executeUpdate();

			JOptionPane.showMessageDialog(null, "New Resident added " + "successfully!!!", "Success",
					JOptionPane.INFORMATION_MESSAGE);

		} catch (SQLException e) {
			reg = null;
			String errorMessage = e.getMessage();
			if (errorMessage.contains("Duplicate")) {
				JOptionPane.showMessageDialog(null, "Resident= " + errorMessage + " already " + "exists", "Error",
						JOptionPane.ERROR_MESSAGE);

			}

		}

		connect.close();

		return reg;

	}

}
