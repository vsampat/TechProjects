package itmd510.p_v.DaoModel;

/*NAME:Vineet Sampat
CWID:A20402683
DATE: 12/02/2017
SOURCE CODE:complaintDaoModel.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/


import java.sql.Statement;

import javax.swing.JOptionPane;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import itmd510.p_v.Model.DBConnector;
import itmd510.p_v.Model.complaintsModel;
import itmd510.p_v.Model.loginModel;

// This Model creates Complaints Table having fields like complaintID, Description, start date time ,status and updated date time.
//In this Model we are having LeaseID used as a foreign key which helps us to know which Resident has raised the complaint , as LeaseID is unique for 
//every Resident.

public class complaintDaoModel {

	DBConnector connect = new DBConnector();
	private Statement statement = null;

	// This is method is used for creating Complaints Table.
	public void createComplaintTable() {
		try {

			statement = connect.getConnection().createStatement();

			String create = "CREATE TABLE IF NOT EXISTS p_v_Complaints" + "(ComplaintID INT(10),"
					+ "ComplaintDescription LONGTEXT," + "CStartDate DATETIME," + "CLastUpdateDate DATETIME,"
					+ "ComplaintStatus VARCHAR(20)," + "LeaseID INT(7),"
					+ "CONSTRAINT pk_ComplaintID PRIMARY KEY (ComplaintID),"
					+ "CONSTRAINT fk_leaseID_1 FOREIGN KEY (LeaseID) REFERENCES p_v_Lease(LeaseID))";

			statement.executeUpdate(create);

			System.out.println("Created Complaints Table in the given database!!!");

		} catch (Exception e) {
			e.printStackTrace();
		}

		connect.close();
	}

	// This method is used for inserting complaints into the table.Intially we
	// are selecting LeaseID for particular Resident, then we are comparing
	// whether the LeaseID equals lID from the complaints table, it checks
	// whether they are same or not. It takes System Date Time when a particular
	// Resident registers Complaint.
	// We also have Validation check points to check whether the Complaint
	// which is being registered has been done for which LeaseID is present or
	// not in the table.
	public complaintsModel insertComplaint(complaintsModel cm) throws ClassNotFoundException {

		DBConnector connect = new DBConnector();

		int leaseID = cm.getLeaseID();
		String complaintDesc = cm.getComplaintDesc();

		int lID = 0;

		ResultSet rs = null;

		try {

			String sql = "SELECT LeaseID from p_v_Lease where LeaseID = (?)";

			PreparedStatement ps = connect.getConnection().prepareStatement(sql);

			ps.setInt(1, leaseID);

			rs = ps.executeQuery();

			while (rs.next())
				lID = rs.getInt(1);

			if (leaseID == lID) {

				JOptionPane.showMessageDialog(null, "Lease ID present in database ", "ALERT",
						JOptionPane.INFORMATION_MESSAGE);

				statement = connect.getConnection().createStatement();

				String squery = null;

				squery = "Select count(ComplaintID) from p_v_Complaints";

				String squery2 = "Select max(ComplaintID) from p_v_Complaints";

				PreparedStatement maxcmpl = (PreparedStatement) connect.getConnection().prepareStatement(squery2);

				ResultSet rs1 = statement.executeQuery(squery);
				ResultSet rs2 = maxcmpl.executeQuery(squery2);

				int gInt = 0;
				int max = 0;
				while (rs1.next())
					gInt = rs1.getInt(1) + 1;

				while (rs2.next())
					max = rs2.getInt(1);

				if (gInt == max) {
					gInt = gInt + 1;

				}

				String status = "new";

				java.sql.Timestamp date = new java.sql.Timestamp(new java.util.Date().getTime());

				PreparedStatement ps1 = (PreparedStatement) connect.getConnection()
						.prepareStatement("insert into p_v_Complaints values(?,?,?,?,?,?)");

				ps1.setInt(1, gInt);
				ps1.setString(2, complaintDesc);
				ps1.setTimestamp(3, date);
				ps1.setTimestamp(4, null);
				ps1.setString(5, status);
				ps1.setInt(6, leaseID);

				ps1.executeUpdate();

				JOptionPane.showMessageDialog(null, "Insert into Complaints table done ", "Success",
						JOptionPane.INFORMATION_MESSAGE);

			} else {

				JOptionPane.showMessageDialog(null,
						"Lease ID is not present kindly view the Lease console for correct ID", "ALERT",
						JOptionPane.INFORMATION_MESSAGE);

			}

		} catch (Exception e) {

			e.printStackTrace();

		}

		connect.close();

		return cm;

	}
  //This Method is used for getting LeaseID from the User who has logged in as the Resident.
	public int gettingLeaseID() throws SQLException {

		String username = loginModel.username;
		int leID = 0;

		try {
			String sqlget = "Select p.LeaseID from p_v_lease p join p_v_resident r on p.ResID = r.ResID where r.Username = '"
					+ username + "'";

			PreparedStatement leasegetter = (PreparedStatement) connect.getConnection().prepareStatement(sqlget);

			ResultSet rs3 = leasegetter.executeQuery(sqlget);

			while (rs3.next())
				leID = rs3.getInt(1);

		} catch (Exception e) {
			e.printStackTrace();
		}
		connect.close();
		return leID;
	}

}
