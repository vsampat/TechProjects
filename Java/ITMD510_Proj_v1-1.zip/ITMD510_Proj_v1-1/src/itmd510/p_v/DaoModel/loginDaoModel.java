package itmd510.p_v.DaoModel;

/*NAME:Vineet Sampat
CWID:A20402683
DATE: 12/02/2017
SOURCE CODE:loginDaoModel.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import itmd510.p_v.proj.Main;

import itmd510.p_v.Model.DBConnector;
import itmd510.p_v.Model.loginModel;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;

public class loginDaoModel {

	DBConnector connect = new DBConnector();
	private Statement statement = null;
	int count = 0;
	public static String Username;
	public static String Password;

	int table = 0;

	// This Method will create User Table once User Registers through
	// Registration Page.

	public void createUserTable() throws SQLException {
		try {
			// create object and call class methods
			statement = connect.getConnection().createStatement();

			String sql = "CREATE TABLE IF NOT EXISTS p_v_user" + "(Username VARCHAR(20) ," + "Password VARCHAR(20),"
					+ "Constraint pk_user PRIMARY KEY (Username));";
			statement.executeUpdate(sql);
			System.out.println("Created user table in given database...");
			table += 1;
			// close connection

		} catch (SQLException e) {
			System.out.print(e.getMessage());
		}
		connect.close();
	}

	public loginModel login(loginModel lm) throws Exception {
		ResultSet rs = null;
		try {

			statement = connect.getConnection().createStatement();
			// pass the sql statement
			String Username = lm.getUserID();
			String Password = lm.getPassword();

			// Query to retrieve Customer Records.
			// Accepts Username and Password in lowercase only.

			String Username_low = Username.toLowerCase();
			String Password_low = Password.toLowerCase();

			// If the Username and Password both equals admin then the control
			// is transfered to the Admin Dashboard which has options like
			// Manage Resident, Manage Lease, Manage Complaints and Manage
			// Maintenance.

			if (Username_low.equals("admin") && Password_low.equals("admin")) {
				// Route to Admin Page
				AnchorPane root = (AnchorPane) FXMLLoader
						.load(getClass().getResource("/itmd510/p_v/Views/adminDashboard.fxml"));
				Scene scene = new Scene(root);
				scene.getStylesheets()
						.add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
				Main.stage.setScene(scene);
				Main.stage.setTitle("Admin Dashboard");
			}
			// If the credentials entered are of User then the control is
			// transfered to the User Welcome Page which has options for
			// Creating Complaints and Maintenance Request , View Rent Bill and
			// Pay Rent.If the User has entered wrong credentials then it throws
			// error message like Invalid Username and Password.
			else {
				statement = connect.getConnection().createStatement();
				String sql = "select Username,Password from p_v_user where Username='" + Username + "' and Password='"
						+ Password + "';";

				rs = statement.executeQuery(sql);

				while (rs.next()) {

					count += 1;
				}
				if (count == 1) {

					System.out.println("Successfull");
					AnchorPane root = (AnchorPane) FXMLLoader
							.load(getClass().getResource("/itmd510/p_v/Views/userWelcomepage.fxml"));
					Scene scene = new Scene(root);
					scene.getStylesheets()
							.add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
					Main.stage.setScene(scene);
					Main.stage.setTitle("Welcome Page");

				} else {
					System.out.println("unsuccessfull");
					JOptionPane.showMessageDialog(null, "Invalid Username or Password", "Error",
							JOptionPane.ERROR_MESSAGE);
					JOptionPane.showMessageDialog(null, "Register First", "Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("No User Exists");
				}

			}
		} catch (SQLException e) {
			lm = null;
			System.out.println("Login Problem " + e);

		}
		connect.close();
		return lm;

	}

}
