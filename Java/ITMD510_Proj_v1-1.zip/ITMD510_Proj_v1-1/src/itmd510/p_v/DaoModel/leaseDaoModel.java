package itmd510.p_v.DaoModel;

/*NAME:Vineet Sampat
CWID:A20402683
DATE: 12/02/2017
SOURCE CODE:leaseDaoModel.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import com.mysql.jdbc.PreparedStatement;

import itmd510.p_v.Model.DBConnector;
import itmd510.p_v.Model.leaseModel;

//This Method will create Lease Table into the Database where we have LeaseID as the primary key; other fields are Lease Start Date and End date.
//We have set the Booking Amount as 400 and have another field as Balance Booking Amount , if the Resident fails to pay amount at 1 time and decides to pay later
//we can update both fields accordingly.

public class leaseDaoModel {

	DBConnector connect = new DBConnector();

	private Statement statement = null;

	public void createLeaseTable() throws SQLException {
		try {
			// create object and call class methods
			statement = connect.getConnection().createStatement();
			// pass sql statement
			String sql = "CREATE TABLE IF NOT EXISTS p_v_Lease" + "(LeaseID INT(7)," + "lStartDate VARCHAR(10),"
					+ "lEndDate VARCHAR(10)," + "bookingAmt NUMERIC(7,2)," + "balBookingAmt NUMERIC(7,2),"
					+ "FlatID VARCHAR(20)," + "ResID INT (7)," + "CONSTRAINT pk_lease PRIMARY KEY (LeaseID),"
					+ "CONSTRAINT fk_flatID FOREIGN KEY (FlatID) REFERENCES p_v_flat(FlatID),"
					+ "CONSTRAINT fk_resID FOREIGN KEY (ResID) REFERENCES p_v_Resident(ResID))";
			statement.executeUpdate(sql);
			System.out.println("Created Lease table in given database...");

		} catch (SQLException e) {
			System.out.print(e.getMessage());
		}

		connect.close();

	}

	// This Method Inserts the values into the Lease Table.We are selecting
	// ResID and FlatID from the Resident and Flat Table .We have also inserted
	// Check point that the same Resident cannot be assigned to more than 1 flat
	// that means each Resident can be assigned to 1 Flat only.F
	public leaseModel insertLease(leaseModel lm) throws ClassNotFoundException {

		DBConnector connect = new DBConnector();

		String FlatID = lm.getFlatID();
		int ResID = lm.getResID();
		String sdate = lm.getLeaseStartDate();
		String edate = lm.getLeaseEndDate();
		double bookingAmt = lm.getBookingAmt();
		double balBookingAmt = lm.getBalBookingAmt();

		int rID = 0;
		String fID = null;
		int RFID = 0;
		String RF = null;

		ResultSet rs = null;
		ResultSet rs1 = null;

		try {
			String sql = "SELECT ResID from p_v_Resident where ResID = (?)";
			String sql1 = "SELECT FlatID from p_v_Flat where FlatID = (?)";
			PreparedStatement prb = (PreparedStatement) connect.getConnection().prepareStatement(sql);

			PreparedStatement prb1 = (PreparedStatement) connect.getConnection().prepareStatement(sql1);

			prb.setInt(1, ResID);
			prb1.setString(1, FlatID);
			rs = prb.executeQuery();
			rs1 = prb1.executeQuery();
			while (rs.next())

				rID = rs.getInt(1);

			while (rs1.next())

				fID = rs1.getString(1);

			String sql2 = "SELECT ResID, FlatID from p_v_lease where ResID = (?) OR FlatID = (?)";

			PreparedStatement checkRF = (PreparedStatement) connect.getConnection().prepareStatement(sql2);

			checkRF.setInt(1, rID);
			checkRF.setString(2, fID);

			ResultSet rs4 = checkRF.executeQuery();
			while (rs4.next()) {
				RFID = rs4.getInt(1);
				RF = rs4.getString(2);
			}
			if (rID == RFID || fID.equals(RF)) {

				JOptionPane.showMessageDialog(null, "Resident already has a lease or a Flat is already assigned",
						"ALERT", JOptionPane.WARNING_MESSAGE);
			} else {

				if (ResID == rID && FlatID.equals(fID)) {

					JOptionPane.showMessageDialog(null, "Resident ID and Flat ID present in database ", "ALERT",
							JOptionPane.INFORMATION_MESSAGE);

					String squery = null;

					squery = "Select count(leaseID) from p_v_Lease";

					String squery2 = "Select max(leaseID) from p_v_lease";

					PreparedStatement cntlease = (PreparedStatement) connect.getConnection().prepareStatement(squery);

					PreparedStatement maxlease = (PreparedStatement) connect.getConnection().prepareStatement(squery2);

					ResultSet rs2 = cntlease.executeQuery();

					ResultSet rs3 = maxlease.executeQuery(squery2);

					// System.out.println(rs2.getInt(1));

					int gInt = 0;
					int max = 0;

					while (rs2.next())
						gInt = rs2.getInt(1) + 1;

					while (rs3.next())
						max = rs3.getInt(1);

					if (gInt == max) {

						gInt = gInt + 1;
					}

					System.out.println(gInt);

					PreparedStatement prb2 = (PreparedStatement) connect.getConnection()
							.prepareStatement("insert into p_v_Lease values(?,?,?,?,?,?,?)");

					prb2.setInt(1, gInt);
					prb2.setString(2, sdate);
					prb2.setString(3, edate);
					prb2.setDouble(4, bookingAmt);
					prb2.setDouble(5, balBookingAmt);
					prb2.setString(6, FlatID);
					prb2.setInt(7, ResID);

					prb2.executeUpdate();

					JOptionPane.showMessageDialog(null, "Insert into Lease table done ", "Success",
							JOptionPane.INFORMATION_MESSAGE);
				} else {

					JOptionPane.showMessageDialog(null, "Resident ID and Flat ID not present in database ", "ALERT",
							JOptionPane.INFORMATION_MESSAGE);
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		connect.close();
		return lm;

	}
}
