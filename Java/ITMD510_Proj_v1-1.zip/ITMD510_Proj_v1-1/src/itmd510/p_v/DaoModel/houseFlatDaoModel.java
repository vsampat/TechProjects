package itmd510.p_v.DaoModel;

/*NAME:Vineet Sampat
CWID:A20402683
DATE: 12/02/2017
SOURCE CODE:houseFlatDaoModel.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

import java.sql.SQLException;
import java.sql.Statement;

import itmd510.p_v.Model.DBConnector;

//This houseFlatDaoModel will create 2 Tables Hosue Table and Flat Table. This both are the Static Tables which are used in this project.
//We have 5 row houses and row house as 8 Flats and flat type is 1bhk,2bhk,3bhk and 4bhk.

public class houseFlatDaoModel {

	DBConnector connect = new DBConnector();

	private Statement statement = null;

	private Boolean prb1 = false;

	private Boolean prb2 = false;

	public void createhouseTable() throws SQLException {
		try {
			// create object and call class methods
			statement = connect.getConnection().createStatement();
			// pass sql statement
			String sql = "CREATE TABLE IF NOT EXISTS p_v_House" + "(HouseID VARCHAR(20)," + "HouseAddress VARCHAR(50),"
					+ "CONSTRAINT pk_HouseID PRIMARY KEY (HouseID))";
			statement.executeUpdate(sql);
			System.out.println("Created House table in the given Database...");
			// close connection

		} catch (SQLException e) {
			System.out.print(e.getMessage());
		}
		connect.close();

	}

	public void createflatTable() throws SQLException {
		try {
			// create object and call class methods
			statement = connect.getConnection().createStatement();
			// pass sql statement
			String sql = "CREATE TABLE IF NOT EXISTS p_v_Flat" + "(FlatID VARCHAR(20)," + "FlatType VARCHAR(50),"
					+ "HouseID VARCHAR(20)," + "CONSTRAINT pk_flatID PRIMARY KEY (flatID),"
					+ "CONSTRAINT fk_houseID FOREIGN KEY (HouseID) REFERENCES p_v_House(HouseID))";
			statement.executeUpdate(sql);
			System.out.println("Created Flat table in given database...");
			// close connection

		} catch (SQLException e) {
			System.out.print(e.getMessage());
		}
		connect.close();

	}

	// This method inserts the row houseid and house Address into the House
	// Table.
	public void insertHouse() {
		try {

			while (!prb1) {
				// create the statement
				statement = connect.getConnection().createStatement();
				// pass the sql string

				String sql1 = "INSERT INTO p_v_House values ('H101','H101 South King Drive');";
				System.out.println("inserted house1");
				statement.executeUpdate(sql1);

				String sql2 = "INSERT INTO p_v_House values ('H102','H102 South King Drive');";
				System.out.println("inserted house2");
				statement.executeUpdate(sql2);

				String sql3 = "INSERT INTO p_v_House values ('H103','H103 South King Drive');";
				System.out.println("inserted house3");
				statement.executeUpdate(sql3);

				String sql4 = "INSERT INTO p_v_House values ('H104','H104 South King Drive');";
				System.out.println("inserted house4");
				statement.executeUpdate(sql4);

				String sql5 = "INSERT INTO p_v_House values ('H105','H105 South King Drive');";
				System.out.println("inserted house5");
				statement.executeUpdate(sql5);

				prb1 = true;
			}
		} catch (SQLException e) {

			System.out.println(e.getMessage());
		}
		connect.close();

	}

	// This Method will insert 8 flats into each Row houses where we have
	// HouseID used as foreign key in the Flat table.
	// FlatID is later used as foreign key in the Lease Table.
	public void insertFlat() {
		try {

			while (!prb2) {
				// create the statement
				statement = connect.getConnection().createStatement();
				// pass the sql string

				String sql1 = "INSERT INTO p_v_Flat values ('F101','1bhk','H101');";
				System.out.println("inserted flat1");
				statement.executeUpdate(sql1);

				String sql2 = "INSERT INTO p_v_Flat values ('F102','2bhk','H101');";
				System.out.println("inserted flat2");
				statement.executeUpdate(sql2);

				String sql3 = "INSERT INTO p_v_Flat values ('F103','3bhk','H101');";
				System.out.println("inserted flat3");
				statement.executeUpdate(sql3);

				String sql4 = "INSERT INTO p_v_Flat values ('F104','4bhk','H101');";
				System.out.println("inserted flat4");
				statement.executeUpdate(sql4);

				String sql5 = "INSERT INTO p_v_Flat values ('F105','1bhk','H101');";
				System.out.println("inserted flat5");
				statement.executeUpdate(sql5);

				String sql6 = "INSERT INTO p_v_Flat values ('F106','2bhk','H101');";
				System.out.println("inserted flat6");
				statement.executeUpdate(sql6);

				String sql7 = "INSERT INTO p_v_Flat values ('F107','3bhk','H101');";
				System.out.println("inserted flat7");
				statement.executeUpdate(sql7);

				String sql8 = "INSERT INTO p_v_Flat values ('F108','4bhk','H101');";
				System.out.println("inserted flat8");
				statement.executeUpdate(sql8);

				String sql9 = "INSERT INTO p_v_Flat values ('F201','1bhk','H102');";
				System.out.println("inserted flat1");
				statement.executeUpdate(sql9);

				String sql10 = "INSERT INTO p_v_Flat values ('F202','2bhk','H102');";
				System.out.println("inserted flat2");
				statement.executeUpdate(sql10);

				String sql11 = "INSERT INTO p_v_Flat values ('F203','3bhk','H102');";
				System.out.println("inserted flat3");
				statement.executeUpdate(sql11);

				String sql12 = "INSERT INTO p_v_Flat values ('F204','4bhk','H102');";
				System.out.println("inserted flat4");
				statement.executeUpdate(sql12);

				String sql13 = "INSERT INTO p_v_Flat values ('F205','1bhk','H102');";
				System.out.println("inserted flat5");
				statement.executeUpdate(sql13);

				String sql14 = "INSERT INTO p_v_Flat values ('F206','2bhk','H102');";
				System.out.println("inserted flat6");
				statement.executeUpdate(sql14);

				String sql15 = "INSERT INTO p_v_Flat values ('F207','3bhk','H102');";
				System.out.println("inserted flat7");
				statement.executeUpdate(sql15);

				String sql16 = "INSERT INTO p_v_Flat values ('F208','4bhk','H102');";
				System.out.println("inserted flat8");
				statement.executeUpdate(sql16);

				String sql17 = "INSERT INTO p_v_Flat values ('F301','1bhk','H103');";
				System.out.println("inserted flat1");
				statement.executeUpdate(sql17);

				String sql18 = "INSERT INTO p_v_Flat values ('F302','2bhk','H103');";
				System.out.println("inserted flat2");
				statement.executeUpdate(sql18);

				String sql19 = "INSERT INTO p_v_Flat values ('F303','3bhk','H103');";
				System.out.println("inserted flat3");
				statement.executeUpdate(sql19);

				String sql20 = "INSERT INTO p_v_Flat values ('F304','4bhk','H103');";
				System.out.println("inserted flat4");
				statement.executeUpdate(sql20);

				String sql21 = "INSERT INTO p_v_Flat values ('F305','1bhk','H103');";
				System.out.println("inserted flat5");
				statement.executeUpdate(sql21);

				String sql22 = "INSERT INTO p_v_Flat values ('F306','2bhk','H103');";
				System.out.println("inserted flat6");
				statement.executeUpdate(sql22);

				String sql23 = "INSERT INTO p_v_Flat values ('F307','3bhk','H103');";
				System.out.println("inserted flat7");
				statement.executeUpdate(sql23);

				String sql24 = "INSERT INTO p_v_Flat values ('F308','4bhk','H103');";
				System.out.println("inserted flat8");
				statement.executeUpdate(sql24);

				String sql25 = "INSERT INTO p_v_Flat values ('F401','1bhk','H104');";
				System.out.println("inserted flat1");
				statement.executeUpdate(sql25);

				String sql26 = "INSERT INTO p_v_Flat values ('F402','2bhk','H104');";
				System.out.println("inserted flat2");
				statement.executeUpdate(sql26);

				String sql27 = "INSERT INTO p_v_Flat values ('F403','3bhk','H104');";
				System.out.println("inserted flat3");
				statement.executeUpdate(sql27);

				String sql28 = "INSERT INTO p_v_Flat values ('F404','4bhk','H104');";
				System.out.println("inserted flat4");
				statement.executeUpdate(sql28);

				String sql29 = "INSERT INTO p_v_Flat values ('F405','1bhk','H104');";
				System.out.println("inserted flat5");
				statement.executeUpdate(sql29);

				String sql30 = "INSERT INTO p_v_Flat values ('F406','2bhk','H104');";
				System.out.println("inserted flat6");
				statement.executeUpdate(sql30);

				String sql31 = "INSERT INTO p_v_Flat values ('F407','3bhk','H104');";
				System.out.println("inserted flat7");
				statement.executeUpdate(sql31);

				String sql32 = "INSERT INTO p_v_Flat values ('F408','4bhk','H104');";
				System.out.println("inserted flat8");
				statement.executeUpdate(sql32);

				String sql33 = "INSERT INTO p_v_Flat values ('F501','1bhk','H105');";
				System.out.println("inserted flat1");
				statement.executeUpdate(sql33);

				String sql34 = "INSERT INTO p_v_Flat values ('F502','2bhk','H105');";
				System.out.println("inserted flat2");
				statement.executeUpdate(sql34);

				String sql35 = "INSERT INTO p_v_Flat values ('F503','3bhk','H105');";
				System.out.println("inserted flat3");
				statement.executeUpdate(sql35);

				String sql36 = "INSERT INTO p_v_Flat values ('F504','4bhk','H105');";
				System.out.println("inserted flat4");
				statement.executeUpdate(sql36);

				String sql37 = "INSERT INTO p_v_Flat values ('F505','1bhk','H105');";
				System.out.println("inserted flat5");
				statement.executeUpdate(sql37);

				String sql38 = "INSERT INTO p_v_Flat values ('F506','2bhk','H105');";
				System.out.println("inserted flat6");
				statement.executeUpdate(sql38);

				String sql39 = "INSERT INTO p_v_Flat values ('F507','3bhk','H105');";
				System.out.println("inserted flat7");
				statement.executeUpdate(sql39);

				String sql40 = "INSERT INTO p_v_Flat values ('F508','4bhk','H105');";
				System.out.println("inserted flat8");
				statement.executeUpdate(sql40);

				prb2 = true;
			}
		} catch (SQLException e) {

			System.out.println(e.getMessage());
		}
		connect.close();

	}
}
