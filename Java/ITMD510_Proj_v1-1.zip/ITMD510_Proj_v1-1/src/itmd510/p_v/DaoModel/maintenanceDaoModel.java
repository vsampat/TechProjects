package itmd510.p_v.DaoModel;

/*NAME:Vineet Sampat
CWID: A20402683
DATE: 12/02/2017
SOURCE CODE:maintenanceDaoModel.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

//In this maintenanceDaoModel we are creating Maintenance request for the Residents which includes Type of Maintenance, Description
//Status,Start Date , Updated Date Time and LeaseID is used as foreign key in this table as its unique for all Residents.

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;

import itmd510.p_v.Model.DBConnector;
import itmd510.p_v.Model.maintenanceModel;

public class maintenanceDaoModel {

	DBConnector connect = new DBConnector();
	private Statement statement = null;

	// This Creates Maintenance Table in the Database.
	public void createMaintenanceTable() {
		try {

			statement = connect.getConnection().createStatement();

			String createtable = "CREATE TABLE IF NOT EXISTS p_v_Maintenance" + "(MaintenanceID INT(10),"
					+ "MaintenanceType VARCHAR(30)," + "MaintenanceDescription LONGTEXT,"
					+ "MaintenanceStatus VARCHAR(20)," + "MStartDate DATETIME," + "MLastUpdateDate DATETIME,"
					+ "LeaseID INT(7)," + "CONSTRAINT pk_MaintenanceID PRIMARY KEY (MaintenanceID),"
					+ "CONSTRAINT fk_leaseID_2 FOREIGN KEY (LeaseID) REFERENCES p_v_Lease(LeaseID))";
			statement.executeUpdate(createtable);

			System.out.println("Created Maintenance Table in the given database!!!");

		} catch (Exception e) {
			e.printStackTrace();
		}

		connect.close();
	}

	public maintenanceModel insertMaintenance(maintenanceModel mm) {

		DBConnector connect = new DBConnector();
		// It checks whether the Maintenance request raised by the Resident has
		// valid LeaseID present in the Database or not then insertion of
		// Maintenance request will take place into the Database.

		int leaseID = mm.getLeaseID();
		String type = mm.getMaintenanceType();
		String maintDesc = mm.getMaintenanceDesc();

		int lID = 0;

		ResultSet rs = null;

		try {

			String sql = "SELECT LeaseID from p_v_Lease where LeaseID = (?)";

			PreparedStatement ps = connect.getConnection().prepareStatement(sql);

			ps.setInt(1, leaseID);

			rs = ps.executeQuery();

			while (rs.next())
				lID = rs.getInt(1);

			if (leaseID == lID) {

				JOptionPane.showMessageDialog(null, "Lease ID present in database ", "ALERT",
						JOptionPane.INFORMATION_MESSAGE);

				statement = connect.getConnection().createStatement();

				String squery = null;

				squery = "Select count(MaintenanceID) from p_v_Maintenance";

				String squery2 = "Select max(MaintenanceID) from p_v_Maintenance";

				PreparedStatement maxmaint = (PreparedStatement) connect.getConnection().prepareStatement(squery2);

				ResultSet rs1 = statement.executeQuery(squery);
				ResultSet rs2 = maxmaint.executeQuery(squery2);

				int gInt = 0;
				int max = 0;
				while (rs1.next())
					gInt = rs1.getInt(1) + 1;

				while (rs2.next())
					max = rs2.getInt(1);

				if (gInt == max) {

					gInt = gInt + 1;
				}

				String status = "new";

				java.sql.Timestamp date = new java.sql.Timestamp(new java.util.Date().getTime());

				PreparedStatement ps1 = (PreparedStatement) connect.getConnection()
						.prepareStatement("insert into p_v_Maintenance values(?,?,?,?,?,?,?)");

				ps1.setInt(1, gInt);
				ps1.setString(2, type);
				ps1.setString(3, maintDesc);
				ps1.setString(4, status);
				ps1.setTimestamp(5, date);
				ps1.setTimestamp(6, null);
				ps1.setInt(7, leaseID);

				ps1.executeUpdate();

				JOptionPane.showMessageDialog(null, "Insert into Maintenancea table done ", "Success",
						JOptionPane.INFORMATION_MESSAGE);

			} else {

				JOptionPane.showMessageDialog(null,
						"Lease ID is not present kindly view the Lease console for correct ID", "ALERT",
						JOptionPane.INFORMATION_MESSAGE);

			}

		} catch (Exception e) {

			e.printStackTrace();

		}

		connect.close();

		return mm;

	}

}
