 package itmd510.p_v.Controllers;

 /*NAME: Vineet Sampat
 CWID:A20402683
 DATE: 12/02/2017
 SOURCE CODE:manageComplaintsController.java
 FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
 */
 
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import itmd510.p_v.Model.DBConnector;
import itmd510.p_v.Model.complaintsModel;
import itmd510.p_v.proj.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

//This Class is used for populating View from the Complaints Table created in the Database. 
//Whenever any new Complaint is added , updated or deleted from the Database it will be reflected in the Table View.

public class manageComplaintsController implements Initializable{
	
	@FXML
	private TableView<complaintsModel>complaintsView;
	
	@FXML
	private TableColumn<?,?> cmplID;
	
	@FXML
	private TableColumn<?,?> cmplnDesc;
	
	@FXML
	private TableColumn<?,?> cmplnStartDate;
	
	@FXML
	private TableColumn<?,?> lstUpdtDate;
	
	@FXML
	private TableColumn<?,?> leaseID;
	
	@FXML
	private TableColumn<?,?> statusID;
	
	@FXML
	private ObservableList<complaintsModel> data;
	
	Connection connection = null;
	//PreparedStatement pst = null;
	ResultSet rs = null;
	
	public manageComplaintsController(){
		
		connection = new DBConnector().getConnection();
		
		System.out.println("The connection for complaints view is done!");
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources){
		
		cmplID.setCellValueFactory(new PropertyValueFactory<>("complaintID"));
		cmplnDesc.setCellValueFactory(new PropertyValueFactory<>("complaintDesc"));
		cmplnStartDate.setCellValueFactory(new PropertyValueFactory<>("startDate"));
		lstUpdtDate.setCellValueFactory(new PropertyValueFactory<>("lastUpdateDate"));
		leaseID.setCellValueFactory(new PropertyValueFactory<>("leaseID"));
		statusID.setCellValueFactory(new PropertyValueFactory<>("complaintStatus"));
		
		ObservableList<complaintsModel> data = FXCollections.observableArrayList();
		
		try{
			
			String squery = "Select * from p_v_Complaints";
			java.sql.PreparedStatement pst = connection.prepareStatement(squery);
			rs = pst.executeQuery();
			
			while(rs.next()){
				data.add(new complaintsModel(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getInt(6)));
				
				complaintsView.setItems(data);
				
			}
			
		}catch(Exception e){
			e.getMessage();
		}
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	//traverses to add complaints page
	public void addComplaints() throws IOException {

		AnchorPane root = (AnchorPane) FXMLLoader.load(getClass().getResource("/itmd510/p_v/Views/addComplaints.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Add Complaints");
	}
	//traverses to update complaints page
	public void updateComplaints() throws IOException {

		AnchorPane root = (AnchorPane) FXMLLoader.load(getClass().getResource("/itmd510/p_v/Views/updateComplaints.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Update Complaints");
	}
	//traverses to delete complaints page
	public void deleteComplaints() throws IOException {

		AnchorPane root = (AnchorPane) FXMLLoader.load(getClass().getResource("/itmd510/p_v/Views/deleteComplaints.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Delete Complaints");
	}
	//coming back to adminDashboard page
	public void back() throws IOException {

		AnchorPane root = (AnchorPane) FXMLLoader.load(getClass().getResource("/itmd510/p_v/Views/adminDashboard.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Admin Dashboard");
	}

}
