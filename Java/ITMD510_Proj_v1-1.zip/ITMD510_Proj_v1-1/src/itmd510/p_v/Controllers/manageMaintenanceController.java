package itmd510.p_v.Controllers;

/*NAME: Vineet Sampat
CWID: A20402683
DATE: 12/02/2017
SOURCE CODE:manageLease2Controller.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/


import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import itmd510.p_v.Model.DBConnector;
import itmd510.p_v.Model.complaintsModel;
import itmd510.p_v.Model.maintenanceModel;
import itmd510.p_v.proj.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

//This Class is used for populating View from the Maintenance Table created in the Database.
//Whenever any new Maintenance Request is added , updated or deleted from the Database it will be reflected in the Table View.

public class manageMaintenanceController implements Initializable {

	@FXML
	private TableView<maintenanceModel> maintView;

	@FXML
	private TableColumn<?, ?> requestID;

	@FXML
	private TableColumn<?, ?> leaseID;

	@FXML
	private TableColumn<?, ?> maintDesc;

	@FXML
	private TableColumn<?, ?> maintType;

	@FXML
	private TableColumn<?, ?> createDate;

	@FXML
	private TableColumn<?, ?> lstUpdtdate;

	@FXML
	private TableColumn<?, ?> statusID;

	@FXML
	private ObservableList<complaintsModel> data;

	Connection connection = null;
	// PreparedStatement pst = null;
	ResultSet rs = null;
	
	public manageMaintenanceController() {

		connection = new DBConnector().getConnection();
		
		System.out.println("The connection for Maintenance view is done!");
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub

		requestID.setCellValueFactory(new PropertyValueFactory<>("maintenanceID"));
		maintDesc.setCellValueFactory(new PropertyValueFactory<>("maintenanceDesc"));
		maintType.setCellValueFactory(new PropertyValueFactory<>("maintenanceType"));
		createDate.setCellValueFactory(new PropertyValueFactory<>("startDate"));
		lstUpdtdate.setCellValueFactory(new PropertyValueFactory<>("lastUpdateDate"));
		statusID.setCellValueFactory(new PropertyValueFactory<>("status"));
		leaseID.setCellValueFactory(new PropertyValueFactory<>("leaseID"));

		ObservableList<maintenanceModel> data = FXCollections.observableArrayList();

		try {

			String squery = "Select * from p_v_Maintenance";
			java.sql.PreparedStatement pst = connection.prepareStatement(squery);
			rs = pst.executeQuery();

			while (rs.next()) {
				data.add(new maintenanceModel(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getInt(7)));

				maintView.setItems(data);
				System.out.println("maintView populated");
			}

		} catch (Exception e) {
			e.getMessage();
		}
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
//The below methods are to traverse to Add, Update, Delete and Manage Maintenance page
	public void addMaintenance() throws Exception {

		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/addMaintenance.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Add Maintenance");
	}

	public void updateMaintenance() throws Exception {

		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/updateMaintenance.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Update Maintenance");
	}

	public void deleteMaintenance() throws Exception {

		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/deleteMaintenance.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Delete Maintenance");
	}
	
	public void back() throws IOException{
		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/adminDashboard.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Admin Dashboard");
	}

}
