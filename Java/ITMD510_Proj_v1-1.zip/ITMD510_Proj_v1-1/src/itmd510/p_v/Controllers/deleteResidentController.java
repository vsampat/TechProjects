package itmd510.p_v.Controllers;

/*NAME:Vineet Sampat
CWID: A20402683
DATE: 12/02/2017
SOURCE CODE:deleteResidentController.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

import java.sql.ResultSet;

import javax.swing.JOptionPane;

import com.mysql.jdbc.PreparedStatement;

import itmd510.p_v.Model.DBConnector;
import itmd510.p_v.proj.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;

public class deleteResidentController {
	@FXML
	private TextField resID;

	private String username = null;

	ResultSet rs = null;

	private String rID;
		
	private String regex = "\\d+";
	
	// This Method will delete the Resident if it wishes to leave our Housing
	// Establishment then along with its ResID its Username will also be
	// deleted.
	// Firstly the Username would be deleted from the User Table and then ResID
	// from the Resident Table.

	public void deleteResident() {

		DBConnector connect = new DBConnector();

		String resID = this.resID.getText();

		if (resID.trim().equals("") || resID == null) {
			JOptionPane.showMessageDialog(null, "Please enter an Resident ID to continue ", "ALERT",
					JOptionPane.WARNING_MESSAGE);
			return;
		} else {
			
			if(!resID.matches(regex)){
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("ALERT");
				alert.setHeaderText(null);
				alert.setContentText("Please insert a numeric ID");
				alert.showAndWait();

				return;

			}

			try {

				String select = "SELECT ResID from p_v_Resident where ResID = (?)";
				PreparedStatement con = (PreparedStatement) connect.getConnection().prepareStatement(select);
				con.setString(1, resID);
				rs = con.executeQuery();

				while (rs.next())

					rID = rs.getString(1);

				if (resID.equals(rID)) {

					JOptionPane.showMessageDialog(null, "Resident ID present in database ", "ALERT",
							JOptionPane.INFORMATION_MESSAGE);

					String updtquery = "Select Username FROM p_v_Resident where ResID = ?";
					PreparedStatement prb = (PreparedStatement) connect.getConnection().prepareStatement(updtquery);
					prb.setString(1, resID);
					rs = prb.executeQuery();
					System.out.println("select username");
					while (rs.next()) {
						username = rs.getString(1);
					}

					String delresident = "DELETE FROM p_v_Resident where ResID = ?";
					PreparedStatement prbdelete2 = (PreparedStatement) connect.getConnection()
							.prepareStatement(delresident);
					prbdelete2.setString(1, resID);
					prbdelete2.executeUpdate();
					System.out.println("delete resident");

					JOptionPane.showMessageDialog(null, "Resident Deleted" + "successfully!!!", "Success",
							JOptionPane.INFORMATION_MESSAGE);

					String deluser = "DELETE FROM p_v_user where Username = ?";
					PreparedStatement prbdelete = (PreparedStatement) connect.getConnection().prepareStatement(deluser);
					prbdelete.setString(1, username);
					prbdelete.executeUpdate();
					System.out.println("delete user");
					JOptionPane.showMessageDialog(null, "User details for the resident deleted " + "successfully!!!",
							"Success", JOptionPane.INFORMATION_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null, "Resident ID not present in database", "ALERT",
							JOptionPane.WARNING_MESSAGE);
				}

			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "This Resident has a lease attached to it. Kindly delete the lease before deleting the Resident. Thank You!!!", "ALERT",
						JOptionPane.WARNING_MESSAGE);
			}

			connect.close();
		}
	}

	// This method is used to route back to the Manage Residents View once the
	// Resident details have been deleted.
	
	public void back() throws Exception {
		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/manageResidents.fxml"));

		Scene scene = new Scene(root, 700, 500);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Manage Residents");
	}

}
