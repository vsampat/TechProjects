package itmd510.p_v.Controllers;

/*NAME:Vineet Sampat
CWID: A20405808/A20402683
DATE: 12/02/2017
SOURCE CODE:deleteLeaseController.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

import java.sql.ResultSet;

import javax.swing.JOptionPane;

import com.mysql.jdbc.PreparedStatement;

import itmd510.p_v.Model.DBConnector;
import itmd510.p_v.proj.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;

public class deleteLeaseController {
	@FXML
	private TextField leaseID;

	private String lID;

	ResultSet rs = null;

	private String regex = "\\d+";
	
	// This Method deletes the Lease Details using LeaseID.It will check
	// whether the value entered in the GUI and Database has complaint ID to be
	// deleted if yes then the value will be deleted else it throws Alert.

	public void deleteLease() {

		DBConnector connect = new DBConnector();

		String leaseID = this.leaseID.getText();

		if (leaseID.trim().equals("") || leaseID == null) {
			JOptionPane.showMessageDialog(null, "Please enter an Lease ID to continue ", "WARNING",
					JOptionPane.WARNING_MESSAGE);
			return;
		} else {

			if (!leaseID.matches(regex)) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("ALERT");
				alert.setHeaderText(null);
				alert.setContentText("Please insert a numeric ID");
				alert.showAndWait();

				return;

			}
			// It selects LeaseID from Lease Table and checks whether the ID
			// entered is same as the value if present in the Database.
			try {

				String sqlquery = "Select LeaseID from p_v_Lease where LeaseID = (?)";

				PreparedStatement prbstmt = (PreparedStatement) connect.getConnection().prepareStatement(sqlquery);

				prbstmt.setString(1, leaseID);

				rs = prbstmt.executeQuery();

				while (rs.next())
					lID = rs.getString(1);

				if (leaseID.equals(lID)) {
					JOptionPane.showMessageDialog(null, "Lease ID present in database ", "ALERT",
							JOptionPane.INFORMATION_MESSAGE);
					
					String delete2 = "DELETE FROM p_v_Rent where LeaseID = (?)";

					PreparedStatement prbdelete2 = (PreparedStatement) connect.getConnection().prepareStatement(delete2);
					prbdelete2.setString(1, leaseID);
					prbdelete2.executeUpdate();
					System.out.println("Rent deleted");
					JOptionPane.showMessageDialog(null,
							"Resident Rent Deleted from the system as well!.", "ALERT",
							JOptionPane.WARNING_MESSAGE);
					
					
					String delete = "DELETE FROM p_v_Lease where LeaseID = (?)";

					PreparedStatement prbdelete = (PreparedStatement) connect.getConnection().prepareStatement(delete);
					prbdelete.setString(1, leaseID);
					prbdelete.executeUpdate();
					System.out.println("Lease deleted");

					JOptionPane.showMessageDialog(null,
							"Lease Deleted successfully!"
									+ " In case you would like to delete the resident completely from the system then please use the Manage Residents Console.",
							"Success", JOptionPane.INFORMATION_MESSAGE);

				} else {
					JOptionPane.showMessageDialog(null,
							"Lease ID not present in database. Kindly recheck the table view again.", "ALERT",
							JOptionPane.WARNING_MESSAGE);

				}

			} catch (Exception e) {

				JOptionPane.showMessageDialog(null,
						"This Lease has some Complaints or Maintenanace requests attached to it. Kindly delete those before deleting the lease. Thank You!!!",
						"ALERT", JOptionPane.WARNING_MESSAGE);

			}

			connect.close();

		}
	}
	// This method is used to route back to the Manage Lease View once the
	// Lease details have been deleted.
	public void back() throws Exception {
		AnchorPane root = (AnchorPane) FXMLLoader.load(getClass().getResource("/itmd510/p_v/Views/manageLease2.fxml"));

		Scene scene = new Scene(root, 790, 506);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Manage Lease");
	}

}
