package itmd510.p_v.Controllers;

/*NAME:Vineet Sampat
CWID: A20402683
DATE: 12/02/2017
SOURCE CODE:updateComplaintsController.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;

import itmd510.p_v.Model.DBConnector;
import itmd510.p_v.proj.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;

//This class updates the Complaint Status and the last updated Date for the Complaint ID. Any New Complaint which is opened when updated to In Progress
//or from In Progress to Resolved automatically last Updated Date and time would be populated in the Database as well as View.
//We also have Validation checks that Status once Resolved cannot be Opened.

public class updateComplaintsController {
	@FXML
	private TextField complaintID;
	@FXML
	private RadioButton inProgress;
	@FXML
	private ToggleGroup ToggleGroup7 = null;
	@FXML
	private RadioButton closed;

	private String cID;

	private String ctype;

	private String check = null;

	private String regex = "\\d+";

	public void updateComplaint() throws SQLException {

		DBConnector connect = new DBConnector();

		String complaintID = this.complaintID.getText();

		ToggleButton p1 = new ToggleButton();

		p1.setToggleGroup(ToggleGroup7);

		RadioButton chk = (RadioButton) p1.getToggleGroup().getSelectedToggle();

		// To check whether the complaintID field is blank or not.

		if (complaintID.trim().equals("")) {

			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("ALERT");
			alert.setHeaderText(null);
			alert.setContentText("Complaint ID Cannot be blank");
			alert.showAndWait();
			return;
		}

		// Displays the value of RadioButton Selected.

		try {
			if (chk.isSelected()) {

				check = (String) chk.getId().toString();

				System.out.println("The value is " + check);

			}
		} catch (Exception e) {

			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("ALERT");
			alert.setHeaderText(null);
			alert.setContentText("Select a radio button");
			alert.showAndWait();
			return;
		}

		if (check.equals("inProgress")) {

			ctype = "In Progress";
		} else {

			ctype = "Resolved";
		}
		try {

			if (!complaintID.matches(regex)) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("ALERT");
				alert.setHeaderText(null);
				alert.setContentText("Please insert a numeric ID");
				alert.showAndWait();

				return;

			}

			String select = "SELECT ComplaintID from p_v_complaints where ComplaintID = (?)";
			PreparedStatement con = (PreparedStatement) connect.getConnection().prepareStatement(select);
			con.setString(1, complaintID);

			ResultSet rs = con.executeQuery();

			while (rs.next())
				cID = rs.getString(1);

			if (complaintID.equals(cID)) {

				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("Success");
				alert.setHeaderText(null);
				alert.setContentText("Value present in the database");
				alert.showAndWait();

				java.sql.Timestamp date = new java.sql.Timestamp(new java.util.Date().getTime());

				String checkstatus = "Select ComplaintStatus from p_v_Complaints where ComplaintID = (?)";
				PreparedStatement cs = (PreparedStatement) connect.getConnection().prepareStatement(checkstatus);
				// cs.setString(1, ctype);
				cs.setString(1, complaintID);
				ResultSet rs1 = cs.executeQuery();

				String stat = null;
				while (rs1.next())
					stat = rs1.getString(1);

				System.out.println(stat);
				System.out.println(ctype);

				if (ctype.equals(stat)) {

					Alert alert2 = new Alert(AlertType.WARNING);
					alert2.setTitle("ALERT");
					alert2.setHeaderText(null);
					alert2.setContentText("The status is already " + ctype + " Kindly change your selection.");
					alert2.showAndWait();

					return;

				} else if (stat.equals("In Progress") || stat.equals("new")) {

					String updtquery = "UPDATE p_v_Complaints SET CLastUpdateDate = (?), ComplaintStatus = (?) WHERE ComplaintID = (?)";
					PreparedStatement psc = (PreparedStatement) connect.getConnection().prepareStatement(updtquery);
					psc.setTimestamp(1, date);
					psc.setString(2, ctype);
					psc.setString(3, complaintID);
					psc.executeUpdate();
					System.out.println("1");

					alert.setTitle("Success");
					alert.setHeaderText(null);
					alert.setContentText("Complaint Status Updated Successfully!!!");
					alert.showAndWait();
				} else {

					Alert alert3 = new Alert(AlertType.WARNING);
					alert3.setTitle("ALERT");
					alert3.setHeaderText(null);
					alert3.setContentText("The status is already Resolved. Kindly create a new request.");
					alert3.showAndWait();

					return;

				}
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("ALERT");
				alert.setHeaderText(null);
				alert.setContentText("ID NOT PRESENT IN DATABASE. KINDLY CHECK THE VIEW TABLE.");
				alert.showAndWait();

				return;

			}
		} catch (Exception e) {
			e.getMessage();
		}

		connect.close();

	}

	// This will transfer the control back to Manage Complaints View once the
	// Complaint status has been updated.

	public void back() throws IOException {
		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/manageComplaints.fxml"));
		Scene scene = new Scene(root, 712, 400);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Manage Complaints");
	}

}
