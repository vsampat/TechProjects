package itmd510.p_v.Controllers;

/*NAME:Vineet Sampat
CWID:A20402683
DATE: 12/02/2017
SOURCE CODE:addComplaintsController.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

import java.io.IOException;

import itmd510.p_v.DaoModel.complaintDaoModel;
import itmd510.p_v.Model.complaintsModel;
import itmd510.p_v.proj.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class addComplaintsController {
	@FXML
	private TextField leaseID;
	@FXML
	private TextArea complaintDescription;

	private String regex = "\\d+";

	// This Method is used for adding Complaints into the Database through GUI.
	// It has validations where if we dont enter LeaseID we get pop-up message
	// that the fields cannot be blank.

	public void addComplaints() {

		String leaseID = this.leaseID.getText();

		String complaintDescription = this.complaintDescription.getText();

		try {

			if (leaseID.trim().equals("") || complaintDescription.trim().equals("")) {

				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("Validate Fields");
				alert.setHeaderText(null);
				alert.setContentText("Details cannot be blank");
				alert.showAndWait();

				return;
			}

			else if (!leaseID.matches(regex)) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("ALERT");
				alert.setHeaderText(null);
				alert.setContentText("Please insert a numeric ID");
				alert.showAndWait();

				return;

			}

			else {
				// Calling Complaints Model for Insertion.
				complaintsModel cm = new complaintsModel();

				int lID = Integer.parseInt(leaseID);

				cm.setLeaseID(lID);
				cm.setComplaintDesc(complaintDescription);

				complaintDaoModel cdam = new complaintDaoModel();

				cdam.insertComplaint(cm);

				System.out.println("Inserted into complaint table!!!");

			}

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	// This method is used to route back to the Manage Complaints View once the
	// Complaint has been logged.
	public void back() throws IOException {

		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/manageComplaints.fxml"));
		Scene scene = new Scene(root, 712, 400);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Manage Complaints");
	}

}
