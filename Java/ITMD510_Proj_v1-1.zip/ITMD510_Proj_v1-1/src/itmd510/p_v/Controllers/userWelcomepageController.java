package itmd510.p_v.Controllers;

/*NAME:Vineet Sampat
CWID: A20402683
DATE: 12/02/2017
SOURCE CODE:userWelcomeController.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

import java.io.IOException;
import java.sql.SQLException;
import itmd510.p_v.DaoModel.complaintDaoModel;
import itmd510.p_v.DaoModel.rentDaoModel;
import itmd510.p_v.proj.Main;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;

public class userWelcomepageController {

	public void viewRent() throws IOException, SQLException {
		try {

			complaintDaoModel cd = new complaintDaoModel();

			// Using gettingLeaseID from the ComplaintDao Model for view Rent
			// Bill
			// which will check if the lease is not created for the Resident
			// then it
			// can't view any Rent Bill.

			int i = cd.gettingLeaseID();

			if (i == 0) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("ALERT");
				alert.setHeaderText(null);
				alert.setContentText(
						"No Lease Created for this user. Kindly contact administrator for lease creation or other information");
				alert.showAndWait();

				return;
			} else {
				// If lease Id is present then the details for the Rent would be
				// created for particular Resident.
				rentDaoModel rdam = new rentDaoModel();
				rdam.insertRent();
				System.out.println("Insert keli re rent!!!!");
				AnchorPane root = (AnchorPane) FXMLLoader
						.load(getClass().getResource("/itmd510/p_v/Views/viewRentBill.fxml"));
				Scene scene = new Scene(root);
				scene.getStylesheets()
						.add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
				Main.stage.setScene(scene);
				Main.stage.setTitle("Rent Page");
				System.out.println("This code executed as you wanted");
			}
		} catch (Exception e) {

			System.out.println("Something Went Wrong!! ");

			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("ALERT");
			alert.setHeaderText(null);
			alert.setContentText("Please Contact the Administrator or System Developer");
			alert.showAndWait();

			return;
		}

	}

	public void addComplaint() throws IOException {

		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/userAddcomplaint.fxml"));
		Scene scene = new Scene(root, 623, 357);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Add Complaint");
	}

	public void addMaintenance() throws IOException {

		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/userAddMaintenance.fxml"));
		Scene scene = new Scene(root, 590, 496);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Add Maintenance");
	}

	public void logout() throws IOException {

		AnchorPane root = (AnchorPane) FXMLLoader.load(getClass().getResource("/itmd510/p_v/Views/projLogin.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Login");
	}

}
