package itmd510.p_v.Controllers;

/*NAME:Vineet Sampat
CWID: A20402683
DATE: 12/02/2017
SOURCE CODE:adminDashboardController.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

import java.io.IOException;
import java.sql.SQLException;
import itmd510.p_v.proj.Main;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;

//This is AdminDashboard which has Functions like Manage Residents, Manage Complaints, Manage Maintenance, Manage Lease and Logout.

public class adminDashboardController {
	
	public void manageResidents() throws IOException {

		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/manageResidents.fxml"));
		Scene scene = new Scene(root,688,500);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Manage Residents");
	}

	public void manageComplaints() throws IOException {

		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/manageComplaints.fxml"));
		Scene scene = new Scene(root,712,400);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Manage Complaints");
	}
	
	public void manageMaintenance() throws IOException {

		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/manageMaintenance.fxml"));
		Scene scene = new Scene(root,852,400);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Manage Maintenance");
	}
	
	public void manageLease() throws IOException, SQLException {

		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/manageLease2.fxml"));
		Scene scene = new Scene(root,790,506);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Manage Lease");
				
	}
	
	public void logout() throws IOException{
		
		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/projLogin.fxml"));
		Scene scene = new Scene(root,500,500);
		Main.stage.setScene(scene);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setTitle("Login");
	}

	
}
