package itmd510.p_v.Controllers;
/*NAME:Vineet Sampat
CWID:A20402683
DATE: 12/02/2017
SOURCE CODE:addMaintenanceController.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/
import java.io.IOException;

import itmd510.p_v.DaoModel.maintenanceDaoModel;
import itmd510.p_v.Model.maintenanceModel;
import itmd510.p_v.proj.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;

//This Method is used for adding Maintenance Request for particular
	// Resident using LeaseID and it checks before taking the request whether
	// the LeaseID is given or not.

public class addMaintenanceController {
	@FXML
	private TextField leaseID;
	@FXML
	private RadioButton plumbing;
	@FXML
	private ToggleGroup ToggleGroup8;
	@FXML
	private RadioButton electrical;
	@FXML
	private RadioButton appliances;
	@FXML
	private RadioButton furniture;
	@FXML
	private RadioButton laundry;
	@FXML
	private RadioButton janitor;
	@FXML
	private TextArea maintDesc;

	private String status = null;
	
	private String regex = "\\d+";

	public void addMaintenance() {

		String leaseID = this.leaseID.getText();

		String maintDesc = this.maintDesc.getText();

		if (leaseID.trim().equals("") || maintDesc.trim().equals("")) {

			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("Validate Fields");
			alert.setHeaderText(null);
			alert.setContentText("Details cannot be blank");
			alert.showAndWait();

			return;
		}
		
		if (!leaseID.matches(regex))
		 {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("ALERT");
			alert.setHeaderText(null);
			alert.setContentText("Please insert a numeric ID");
			alert.showAndWait();

			return;

		}
		// This checks whether the Toggle selection is made using Radio Button.
		
		ToggleButton p1 = new ToggleButton();

		p1.setToggleGroup(ToggleGroup8);

		RadioButton chk = (RadioButton) p1.getToggleGroup().getSelectedToggle();

		try {
			if (chk.isSelected()) {

				status = (String) chk.getId().toString();

				System.out.println("The value is " + status);

			}
		} catch (Exception e) {

			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("ALERT");
			alert.setHeaderText(null);
			alert.setContentText("Select a radio button");
			alert.showAndWait();
			return;
			
		}
		
		// We have 6 types of Maintenance Request like Plumbing,
		// Electrical,appliances,Furniture, Laundry and Janitor.As per the
		// Selection made the values would be entered into the Database.

		if (status.equals("plumbing"))
		{

			status = "Plumbing";
			
			System.out.println("status set as" + status);

		} else if (status.equals("electrical")) {

			status = "Electrical Wiring";
			System.out.println("status set as" + status);
			
		} else if (status.equals("appliances")) {

			status = "Appliances";
			
			System.out.println("status set as" + status);
			
		} else if (status.equals("furniture")) {
			
			status = "Furniture Work";
			System.out.println("status set as" + status);
			
		} else if (status.equals("laundry"))
				{
			
			status = "Laundry";
			System.out.println("status set as" + status);
			
		} else 
		{
			
			status = "Janitor";
			System.out.println("status set as" + status);
		}
		
		maintenanceModel mm = new maintenanceModel();
		
		int lID = Integer.parseInt(leaseID);
		
		System.out.println(status);
		
		mm.setLeaseID(lID);
		mm.setMaintenanceDesc(maintDesc);
		mm.setMaintenanceType(status);
		
		maintenanceDaoModel mdam = new maintenanceDaoModel();
		
		mdam.insertMaintenance(mm);
		
		System.out.println("Inserted Data into Maintenance Table!");
		

	}
	
	// This method is used to route back to the Manage Maintenance View once the
	// Maintenance Request has been recorded for the Resident.
	public void back() throws IOException{
		
		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/manageMaintenance.fxml"));
		Scene scene = new Scene(root,852,400);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Manage Maintenance");
		
	}

}
