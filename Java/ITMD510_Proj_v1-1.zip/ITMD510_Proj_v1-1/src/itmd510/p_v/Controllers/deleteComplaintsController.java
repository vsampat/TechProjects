package itmd510.p_v.Controllers;

/*NAME:Vineet Sampat
CWID: A20402683
DATE: 12/02/2017
SOURCE CODE:deleteComplaintsController.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/
import java.io.IOException;
import java.sql.ResultSet;

import com.mysql.jdbc.PreparedStatement;

import itmd510.p_v.Model.DBConnector;
import itmd510.p_v.proj.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;

public class deleteComplaintsController {
	@FXML
	private TextField complaintID;

	private String cID;

	private String regex = "\\d+";

	ResultSet rs = null;

	// This Method deletes the Complaints using ComplaintID.It will check
	// whether the value entered in the GUI and Database has complaint ID to be
	// deleted if yes then the value will be deleted else it throws Alert.

	public void deleteComplaint() {

		DBConnector connect = new DBConnector();

		String complaintID = this.complaintID.getText();

		if (complaintID.trim().equals("") || complaintID == null) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("ALERT");
			alert.setHeaderText(null);
			alert.setContentText("ID Cannot be blank");
			alert.showAndWait();
			return;
		} else {

			if (!complaintID.matches(regex)) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("ALERT");
				alert.setHeaderText(null);
				alert.setContentText("Please insert a numeric ID");
				alert.showAndWait();

				return;

			}

			try {

				String sqldelete = "Select ComplaintID from p_v_Complaints where ComplaintID = (?)";

				PreparedStatement prbstmt = (PreparedStatement) connect.getConnection().prepareStatement(sqldelete);

				prbstmt.setString(1, complaintID);

				rs = prbstmt.executeQuery();

				while (rs.next())
					cID = rs.getString(1);

				if (complaintID.equals(cID)) {

					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("SUCCESS");
					alert.setHeaderText(null);
					alert.setContentText("ID Present in the table");
					alert.showAndWait();

					String delete = "DELETE FROM p_v_Complaints where ComplaintID = (?)";

					PreparedStatement prbdelete = (PreparedStatement) connect.getConnection().prepareStatement(delete);
					prbdelete.setString(1, complaintID);
					prbdelete.executeUpdate();
					System.out.println("Complaint deleted");

					alert.setTitle("SUCCESS");
					alert.setHeaderText(null);
					alert.setContentText("Complaint Deleted Successfully!");
					alert.showAndWait();
					return;
				} else {

					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("ALERT");
					alert.setHeaderText(null);
					alert.setContentText("ID not Present in the table");
					alert.showAndWait();
					return;

				}

			} catch (Exception e) {

				e.printStackTrace();

			}

			connect.close();

		}

	}

	// This method is used to route back to the Manage Complaints View once the
	// Complaint has been deleted.

	public void back() throws IOException {
		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/manageComplaints.fxml"));
		Scene scene = new Scene(root, 712, 400);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Manage Complaints");
	}
}
