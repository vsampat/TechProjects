package itmd510.p_v.Controllers;

/*NAME:Vineet Sampat
CWID:A20402683
DATE: 12/02/2017
SOURCE CODE:updateLeaseController.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

import java.io.IOException;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

import javax.swing.JOptionPane;

import com.mysql.jdbc.PreparedStatement;

import itmd510.p_v.Model.DBConnector;
import itmd510.p_v.proj.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.DatePicker;
import javafx.scene.layout.AnchorPane;

//In this Controller we have fields like Balance Booking Amount and Lease End date which are the fields that are getting updated.

public class updateLeaseController {
	@FXML
	private TextField leaseID;
	@FXML
	private TextField balbookAmt;

	@FXML
	private DatePicker edate;

	private ResultSet rs;

	private ResultSet rs1;

	private String lID;

	private double bal = 0.0;

	private double bookamt = 0.0;

	private double balamt1 = 0.0;

	private double balAmt = 0.0;

	private String es;

	private String regex = "\\d+";

	public void updateLease() {

		DBConnector connect = new DBConnector();

		String leaseID = this.leaseID.getText();
		String balbookAmt = this.balbookAmt.getText();

		SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

		try {

			es = ft.format(ft.parse(this.edate.getValue().toString()));

		} catch (Exception e) {

			es = null;
		}

		// To check whether fields for which we are updating should not be
		// blank.
		try {

			if (leaseID == null || leaseID.trim().equals("")) {

				JOptionPane.showMessageDialog(null, "Lease ID cannot be null ", "ALERT", JOptionPane.WARNING_MESSAGE);
				return;

			}

			else if (!leaseID.matches(regex)) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("ALERT");
				alert.setHeaderText(null);
				alert.setContentText("Please insert a numeric ID");
				alert.showAndWait();

				return;

			}

			// Check to enter atleast Balance Booking Amount or Lease end date
			// so that one of the field can be updated.
			else if (leaseID != null && (balbookAmt == null || balbookAmt.trim().equals(""))
					&& (es == null || es.trim().equals(""))) {

				JOptionPane.showMessageDialog(null,
						"Please insert either Balance Booking Amount or Lease End Date that are to be updated",
						"ALERT", JOptionPane.WARNING_MESSAGE);
				return;

			} else if (leaseID != null && (es == null || es.trim().equals("")) && (balbookAmt != null)) {

				if (!balbookAmt.matches(regex)) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("ALERT");
					alert.setHeaderText(null);
					alert.setContentText("Please insert a number");
					alert.showAndWait();

					return;

				}

				String select = "SELECT leaseID from p_v_lease where LeaseID = (?)";
				PreparedStatement con = (PreparedStatement) connect.getConnection().prepareStatement(select);
				con.setString(1, leaseID);
				rs = con.executeQuery();

				while (rs.next())

					lID = rs.getString(1);

				if (leaseID.equals(lID)) {

					JOptionPane.showMessageDialog(null, "Lease ID present in database ", "ALERT",
							JOptionPane.INFORMATION_MESSAGE);

					String slct = "select balBookingAmt from p_v_Lease where LeaseID = (?)";

					java.sql.PreparedStatement prbslct = connect.getConnection().prepareStatement(slct);
					prbslct.setString(1, leaseID);
					rs1 = prbslct.executeQuery();

					balAmt = Double.parseDouble(balbookAmt);

					while (rs1.next())
						bal = Double.parseDouble(rs1.getString(1));

					// Setting Booking Amount to 400 and temporary variable will
					// store the Balance Amount and Balance which is yet to be
					// paid.

					double temp = bal - balAmt;

					System.out.println("temp value" + temp);

					if (temp == 0) {

						double book = 400.00;

						String updtquery = "UPDATE p_v_Lease SET bookingAmt = (?), balBookingAmt = (?) WHERE LeaseID = (?)";
						PreparedStatement prb = (PreparedStatement) connect.getConnection().prepareStatement(updtquery);
						prb.setDouble(1, book);
						prb.setDouble(2, temp);
						prb.setString(3, leaseID);
						prb.executeUpdate();
						System.out.println("1");

						JOptionPane.showMessageDialog(null, "Balance Amount updated successfully " + "successfully!!!",
								"Success", JOptionPane.INFORMATION_MESSAGE);

					} else if (temp > 0) {

						String slct1 = "select bookingAmt, balBookingAmt from p_v_Lease where LeaseID = (?)";

						java.sql.PreparedStatement prbslct1 = connect.getConnection().prepareStatement(slct1);
						prbslct1.setString(1, leaseID);
						rs1 = prbslct1.executeQuery();

						while (rs1.next()) {
							bookamt = Double.parseDouble(rs1.getString(1));
							balamt1 = Double.parseDouble(rs1.getString(2));
						}

						// If the value in Temp is greater than balAmt is added
						// in Booking Amount and is deducted from the bal.

						bookamt = bookamt + balAmt;
						bal = balamt1 - balAmt;

						String updtquery1 = "UPDATE p_v_Lease SET bookingAmt = (?), balBookingAmt = (?) WHERE LeaseID = (?)";
						PreparedStatement prb1 = (PreparedStatement) connect.getConnection()
								.prepareStatement(updtquery1);
						prb1.setDouble(1, bookamt);
						prb1.setDouble(2, bal);
						prb1.setString(3, leaseID);
						prb1.executeUpdate();
						System.out.println("2");

						JOptionPane.showMessageDialog(null, "Balance Amount updated successfully " + "successfully!!!",
								"Success", JOptionPane.INFORMATION_MESSAGE);

					} else {

						JOptionPane.showMessageDialog(null, "Kindly recheck the balance amount in the table again",
								"ALERT", JOptionPane.WARNING_MESSAGE);
					}
				} else {

					JOptionPane.showMessageDialog(null, "Lease ID not present in database", "ALERT",
							JOptionPane.WARNING_MESSAGE);
				}

			} else if (leaseID != null && (balbookAmt == null || balbookAmt.trim().equals("")) && (es != null)) {

				String select2 = "SELECT leaseID from p_v_lease where LeaseID = (?)";
				PreparedStatement con1 = (PreparedStatement) connect.getConnection().prepareStatement(select2);
				con1.setString(1, leaseID);
				rs = con1.executeQuery();

				while (rs.next())

					lID = rs.getString(1);

				// Checks whether the Lease ID entered in the form and present
				// in the Database matches or not.If yes then update Lease End
				// date.

				if (leaseID.equals(lID)) {

					JOptionPane.showMessageDialog(null, "Lease ID present in database ", "ALERT",
							JOptionPane.INFORMATION_MESSAGE);

					String updtquery1 = "UPDATE p_v_Lease SET lEndDate=(?) WHERE LeaseID = (?)";
					PreparedStatement prb1 = (PreparedStatement) connect.getConnection().prepareStatement(updtquery1);
					prb1.setString(1, es);
					prb1.setString(2, leaseID);
					prb1.executeUpdate();
					System.out.println("3");

					JOptionPane.showMessageDialog(null, "Lease End Date update successfully!!! " + "successfully!!!",
							"Success", JOptionPane.INFORMATION_MESSAGE);
				} else {

					JOptionPane.showMessageDialog(null, "Lease ID not present in database", "ALERT",
							JOptionPane.WARNING_MESSAGE);
				}

			} else {

				JOptionPane.showMessageDialog(null, "Sorry We can only update any one of the values", "ALERT",
						JOptionPane.WARNING_MESSAGE);

				return;
			}

		} catch (Exception e) {

			System.out.println("Something Went Wrong!! ");

			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("ALERT");
			alert.setHeaderText(null);
			alert.setContentText("Please Contact the Administrator or System Developer");
			alert.showAndWait();

			return;
		}

		connect.close();
	}

	// This will Transfer the control back to the Manage Lease once any of them
	// Balance Amount or End date is updated.

	public void back() throws IOException {

		AnchorPane root = (AnchorPane) FXMLLoader.load(getClass().getResource("/itmd510/p_v/Views/manageLease2.fxml"));

		Scene scene = new Scene(root, 790, 506);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Manage Lease");
	}
}
