package itmd510.p_v.Controllers;

/*NAME: Vineet Sampat
CWID: A20402683
DATE: 12/02/2017
SOURCE CODE:registrationPage2Controller.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

import itmd510.p_v.DaoModel.loginDaoModel;
import itmd510.p_v.DaoModel.registrationDaoModel;
import itmd510.p_v.Model.registerModel;
import itmd510.p_v.proj.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;

public class registrationPage2Controller {
	@FXML
	private TextField firstname;
	@FXML
	private TextField lastname;
	@FXML
	private TextField contact;
	@FXML
	private TextField email;
	@FXML
	private TextField username;
	@FXML
	private TextField password;
	@FXML
	private TextField confirmpassword;
	@FXML
	private TextField ssn;
	@FXML
	private RadioButton student;
	@FXML
	private RadioButton worker;
	@FXML
	private RadioButton citizen;
	@FXML
	private ToggleGroup ToggleGroup1 = null;

	private String rtype;

	// Using Regular Expressions for SSN, Email-ID , Contact Number and Name.

	private String exprsnNumber = "^[0-9]{10}$";
	private String emailexprsn = "^([_a-zA-Z0-9-]+(\\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*(\\.[a-zA-Z]{1,6}))?$";
	private String ssnexprsn = "^\\d{3}[- ]?\\d{2}[- ]?\\d{4}$";
	private String name = "^[a-zA-Z\\s]*$";

	public void registerResident() {

		String firstname = this.firstname.getText();
		String lastname = this.lastname.getText();
		String contact = this.contact.getText();
		String email = this.email.getText();
		String username = this.username.getText();
		String password = this.password.getText();
		String confirmpassword = this.confirmpassword.getText();
		String ssn = this.ssn.getText();
		boolean student = this.student.isSelected();
		boolean worker = this.worker.isSelected();
		boolean citizen = this.citizen.isSelected();

		// If any of the details are not added in the Form , there would be
		// pop-up to enter the details.

		try

		{

			if (firstname.trim().equals("") || lastname.trim().equals("") || contact.trim().equals("")
					|| email.trim().equals("") || username.trim().equals("") || password.trim().equals("")
					|| confirmpassword.trim().equals("")) {

				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("Validate Fields");
				alert.setHeaderText(null);
				alert.setContentText("Details cannot be blank");
				alert.showAndWait();

				return;
			}

			else if (!firstname.matches(name)) {

				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("Error");
				alert.setHeaderText(null);
				alert.setContentText("please enter proper first name");
				alert.showAndWait();

				return;

			}

			else if (!lastname.matches(name)) {

				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("Error");
				alert.setHeaderText(null);
				alert.setContentText("please enter proper first name");
				alert.showAndWait();

				return;

			}

			else if (!contact.matches(exprsnNumber)) {

				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("Error");
				alert.setHeaderText(null);
				alert.setContentText("please enter 10 digit contact number");
				alert.showAndWait();

				return;

			} else if (!email.matches(emailexprsn)) {

				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("Error");
				alert.setHeaderText(null);
				alert.setContentText("Please enter valid email address");
				alert.showAndWait();

				return;

			} else if (!password.equals(confirmpassword)) {

				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("Error");
				alert.setHeaderText(null);
				alert.setContentText("The password is not same. Kindly enter the same password in both the places.");
				alert.showAndWait();

				return;

			} else if (!ssn.matches(ssnexprsn)) {

				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("Error");
				alert.setHeaderText(null);
				alert.setContentText("Please enter valid SSN number The format should be e.g. 879-89-8989.");
				alert.showAndWait();

				return;

			}

			else {

				if (student) {

					rtype = "student";

					System.out.println("The value for status is set as " + rtype);

				} else if (worker) {

					rtype = "worker";

					System.out.println("This loop ran and value set is " + rtype);
				} else if (citizen) {
					rtype = "citizen";
				} else {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("ALERT");
					alert.setHeaderText(null);
					alert.setContentText("Select the type of resident");
					alert.showAndWait();

					return;

				}

				registerModel reg = new registerModel();
				reg.setUserID(username);
				reg.setFirstName(firstname);
				reg.setLastName(lastname);
				reg.setRtype(rtype);
				reg.setContactNo(contact);
				reg.setEmailID(email);
				reg.setPassword(password);
				reg.setConfirmPswd(confirmpassword);
				reg.setSSN(ssn);

				System.out.println("The rtype is" + rtype);
				loginDaoModel ldm = new loginDaoModel();

				ldm.createUserTable();

				registrationDaoModel rd = new registrationDaoModel();
				registerModel rdcheck;
				rdcheck = rd.insertUser(reg);
				// Check if username fails then don't insert into the table
				if (rdcheck == null) {

					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("ALERT");
					alert.setHeaderText(null);
					alert.setContentText("Please change your username as its already present in the system");
					alert.showAndWait();

					return;
				}

				// Creates the User Table.
				registrationDaoModel rd1 = new registrationDaoModel();
				rd1.createTable();

				// insert Resident date
				registrationDaoModel rd2 = new registrationDaoModel();
				rd2.insertResident(reg);

				System.out.println("Clearing the filled values");
				// clearing the form
				clear();

			}
		}

		catch (Exception e) {

			System.out.println("Something Went Wrong!! ");

			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("ALERT");
			alert.setHeaderText(null);
			alert.setContentText("Please Contact the Administrator or System Developer");
			alert.showAndWait();

			return;
		}

	}

	public void login() throws Exception {
		AnchorPane root = (AnchorPane) FXMLLoader.load(getClass().getResource("/itmd510/p_v/Views/projLogin.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Login");
	}

	public void back() throws Exception {
		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/manageResidents.fxml"));

		Scene scene = new Scene(root, 700, 500);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Manage Residents");
	}

	public void clear() {

		this.firstname.setText("");
		this.lastname.setText("");
		this.contact.setText("");
		this.email.setText("");
		this.username.setText("");
		this.password.setText("");
		this.confirmpassword.setText("");
		this.ssn.setText("");
		this.student.setSelected(false);
		this.worker.setSelected(false);
		this.citizen.setSelected(false);

	}

}
