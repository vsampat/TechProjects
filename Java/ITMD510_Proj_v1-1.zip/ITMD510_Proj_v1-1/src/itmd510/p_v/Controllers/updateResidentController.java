package itmd510.p_v.Controllers;

/*NAME:Vineet Sampat
CWID: A20402683
DATE: 12/02/2017
SOURCE CODE:updateResidentController.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import com.mysql.jdbc.PreparedStatement;

import itmd510.p_v.Model.DBConnector;
import itmd510.p_v.proj.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;

//This Class will updates details like email-id and Contact-Number. We have used Validation checks like if Res ID is null we cannot update the details.

public class updateResidentController {
	@FXML
	private TextField resID;
	@FXML
	private TextField email;
	@FXML
	private TextField Contact;

	private ResultSet rs;

	private String rID;
	
	private String regex = "\\d+";
	
	private String exprsnNumber = "^[0-9]{10}$";
	private String emailexprsn = "^([_a-zA-Z0-9-]+(\\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*(\\.[a-zA-Z]{1,6}))?$";

	public void updateResident() throws IOException, SQLException {

		DBConnector connect = new DBConnector();

		String resID = this.resID.getText();
		String email = this.email.getText();
		String Contact = this.Contact.getText();

		System.out.println("email is:" + email);
		System.out.println("Contact is:" + Contact);
		
		
		if(!resID.matches(regex)){
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("ALERT");
			alert.setHeaderText(null);
			alert.setContentText("Please insert a numeric ID");
			alert.showAndWait();

			return;

		}
			 		
		else{
		
		try {
			if (resID == null || resID.trim().equals("")) {

				JOptionPane.showMessageDialog(null, "Resident ID cannot be null ", "ALERT",
						JOptionPane.WARNING_MESSAGE);
				return;

			}
			else if (resID!=null && (Contact == null || Contact.trim().equals("")) && (email == null || email.trim().equals(""))) {

				JOptionPane.showMessageDialog(null,
						"Please insert either email or contact or both the values that are to be updated", "ALERT",
						JOptionPane.WARNING_MESSAGE);
				return;

			}

			else if (resID!=null && (email == null || email.trim().equals("")) && (Contact!=null)) {

				if (!Contact.matches(exprsnNumber)) {

					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("Error");
					alert.setHeaderText(null);
					alert.setContentText("please enter 10 digit contact number");
					alert.showAndWait();

					return;
				}

				
				
				
				String select = "SELECT ResID from p_v_Resident where ResID = (?)";
				PreparedStatement con = (PreparedStatement) connect.getConnection().prepareStatement(select);
				con.setString(1, resID);
				rs = con.executeQuery();

				while (rs.next())

					rID = rs.getString(1);
				
				// Updates the Contact details for the Resident.
				
				if (resID.equals(rID)) {

					JOptionPane.showMessageDialog(null, "Resident ID present in database ", "ALERT",
							JOptionPane.INFORMATION_MESSAGE);

					String updtquery = "UPDATE p_v_Resident SET Contact=(?) WHERE ResID = (?)";
					PreparedStatement prb = (PreparedStatement) connect.getConnection().prepareStatement(updtquery);
					prb.setString(1, Contact);
					prb.setString(2, resID);
					prb.executeUpdate();
					System.out.println("1");

					JOptionPane.showMessageDialog(null, "Resident Contact Updated " + "successfully!!!", "Success",
							JOptionPane.INFORMATION_MESSAGE);
				} else {

					JOptionPane.showMessageDialog(null, "Resident ID not present in database", "ALERT",
							JOptionPane.WARNING_MESSAGE);
				}
			} else if (resID!=null && (Contact == null || Contact.trim().equals("")) && email!=null) {

				if (!email.matches(emailexprsn)) {

					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("Error");
					alert.setHeaderText(null);
					alert.setContentText("Please enter valid email address");
					alert.showAndWait();

					return;

				}				
				String select = "SELECT ResID from p_v_Resident where ResID = (?)";
				PreparedStatement con = (PreparedStatement) connect.getConnection().prepareStatement(select);
				con.setString(1, resID);
				rs = con.executeQuery();

				while (rs.next())

					rID = rs.getString(1);

				if (resID.equals(rID)) {

					JOptionPane.showMessageDialog(null, "Resident ID present in database ", "ALERT",
							JOptionPane.INFORMATION_MESSAGE);

					String updtquery = "UPDATE p_v_Resident SET Email=(?) WHERE ResID = (?)";
					PreparedStatement prb = (PreparedStatement) connect.getConnection().prepareStatement(updtquery);
					prb.setString(1, email);
					prb.setString(2, resID);
					prb.executeUpdate();
					System.out.println("2");
					JOptionPane.showMessageDialog(null, "Resident EmailID Updated " + "successfully!!!", "Success",
							JOptionPane.INFORMATION_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null, "Resident ID not present in database", "ALERT",
							JOptionPane.WARNING_MESSAGE);
				}
			}

			// Checks if the Resident ID equals the value from the Database
			// then it will update the details in the Resident Table.

			// Updates both Contact and Email details in the Database.

			else {

				String select = "SELECT ResID from p_v_Resident where ResID = (?)";
				PreparedStatement con = (PreparedStatement) connect.getConnection().prepareStatement(select);
				con.setString(1, resID);
				rs = con.executeQuery();

				while (rs.next())

					rID = rs.getString(1);
				

				if (resID.equals(rID)) {

					JOptionPane.showMessageDialog(null, "Resident ID present in database ", "ALERT",
							JOptionPane.INFORMATION_MESSAGE);

					String updtquery = "UPDATE p_v_Resident SET Email=(?),Contact=(?) WHERE ResID = (?)";
					PreparedStatement prb = (PreparedStatement) connect.getConnection().prepareStatement(updtquery);
					prb.setString(1, email);
					prb.setString(2, Contact);
					prb.setString(3, resID);
					prb.executeUpdate();
					System.out.println("3");
					JOptionPane.showMessageDialog(null, "Resident Detail Updated " + "successfully!!!", "Success",
							JOptionPane.INFORMATION_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null, "Resident ID not present in database", "ALERT",
							JOptionPane.WARNING_MESSAGE);
				}
			}

		} catch (Exception e) {

			System.out.println("Something Went Wrong!! ");

			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("ALERT");
			alert.setHeaderText(null);
			alert.setContentText("Please Contact the Administrator or System Developer");
			alert.showAndWait();

			return;
		}

		connect.close();
		}
	}
	
	// This will transfer the control back to Manage Residents view once the
	// details have been updated successfully.

	public void back() throws Exception {
		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/manageResidents.fxml"));
		Scene scene = new Scene(root, 700, 500);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Manage Residents");
	}

}
