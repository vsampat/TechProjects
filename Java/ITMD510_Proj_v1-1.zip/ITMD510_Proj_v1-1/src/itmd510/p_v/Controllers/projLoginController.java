package itmd510.p_v.Controllers;

/*NAME: Vineet Sampat
CWID:A20402683
DATE: 12/02/2017
SOURCE CODE:projLoginController.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

import itmd510.p_v.DaoModel.complaintDaoModel;
import itmd510.p_v.DaoModel.houseFlatDaoModel;
import itmd510.p_v.DaoModel.leaseDaoModel;
import itmd510.p_v.DaoModel.loginDaoModel;
import itmd510.p_v.DaoModel.maintenanceDaoModel;
import itmd510.p_v.DaoModel.rentDaoModel;
import itmd510.p_v.Model.loginModel;
import itmd510.p_v.proj.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

public class projLoginController {

	@FXML
	private TextField username;

	@FXML
	private TextField password;

	public void login() throws Exception {

		String username = this.username.getText();
		String password = this.password.getText();

		// In this Validation takes place whether the Username and Password are
		// entered or not. If both are entered then we have House, Flat,
		// Complaints, Maintenance and Rent Table created.

		try {
			if (username.equals("") && password.equals("")) {

				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("Validate Fields");
				alert.setHeaderText(null);
				alert.setContentText("Username or Password Cannot be blank");
				alert.showAndWait();

				return;
			}

			else {

				loginModel cum = new loginModel();
				cum.setUserID(username);

				cum.setPassword(password);

				loginDaoModel cud = new loginDaoModel();
				cud.createUserTable();
				cud.login(cum);
				System.out.println("User Table Created Successfully");

				leaseDaoModel ledm = new leaseDaoModel();

				ledm.createLeaseTable();

				houseFlatDaoModel hfdm = new houseFlatDaoModel();

				hfdm.createhouseTable();
				System.out.println("House table created");

				hfdm.createflatTable();

				System.out.println("Flat table created");

				hfdm.insertHouse();

				System.out.println("House table populated");

				hfdm.insertFlat();

				System.out.println("Flat table populated");

				complaintDaoModel cdm = new complaintDaoModel();

				cdm.createComplaintTable();

				System.out.println("Complaints Table created");

				maintenanceDaoModel mdm = new maintenanceDaoModel();

				mdm.createMaintenanceTable();

				System.out.println("Maintenance Table created");

				rentDaoModel rdaom = new rentDaoModel();

				rdaom.createRentTable();

				System.out.println("Rent Table created");

			} // end of else
		} catch (Exception e) {
			e.getMessage();
		}

	}

	// This method is used for Registration if any Resident has newly joined our
	// Housing Establishment.

	public void register() throws Exception {

		AnchorPane root = (AnchorPane) FXMLLoader
				.load(getClass().getResource("/itmd510/p_v/Views/registrationPage2.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
		Main.stage.setScene(scene);
		Main.stage.setTitle("Registration Page");
	}

}
