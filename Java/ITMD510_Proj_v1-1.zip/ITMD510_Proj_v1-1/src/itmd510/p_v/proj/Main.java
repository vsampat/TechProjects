package itmd510.p_v.proj;

/*NAME:Vineet Sampat
CWID:A20402683
DATE: 12/02/2017
SOURCE CODE:Main.java
FINAL PROJECT : HOUSING AND RENT MANAGEMENT SYSTEM.
*/

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;

//This is the Main Class which will have Login Page of HOUSING AND RENT MANAGEMENT SYSTEM.

public class Main extends Application {

	public static Stage stage;

	public void start(Stage primaryStage) {
		try {
			stage = primaryStage;
			Parent root = FXMLLoader.load(getClass().getResource("/itmd510/p_v/Views/projLogin.fxml"));
			Scene scene = new Scene(root, 500, 500);
			scene.getStylesheets().add(getClass().getResource("/itmd510/p_v/proj/application.css").toExternalForm());
			stage.setScene(scene);
			stage.setTitle("Login");
			stage.show();
			stage.resizableProperty().setValue(Boolean.FALSE);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);

	}
}